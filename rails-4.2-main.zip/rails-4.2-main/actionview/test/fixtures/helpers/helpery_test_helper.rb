module HelperyTestHelper
  def helpery_test
    "Default"
  end
end
