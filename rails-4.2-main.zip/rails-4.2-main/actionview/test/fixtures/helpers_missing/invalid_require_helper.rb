require 'very_invalid_file_name'

module InvalidRequireHelper
end

