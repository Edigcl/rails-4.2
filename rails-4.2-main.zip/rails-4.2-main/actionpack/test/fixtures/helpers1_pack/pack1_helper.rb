module Pack1Helper
  def conflicting_helper
    "pack1"
  end
end
